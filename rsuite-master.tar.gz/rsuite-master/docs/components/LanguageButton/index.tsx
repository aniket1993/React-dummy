import LanguageButton from './LanguageButton';

export default LanguageButton;
