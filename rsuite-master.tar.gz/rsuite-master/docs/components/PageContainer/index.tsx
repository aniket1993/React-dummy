import PageContainer from './PageContainer';

export default PageContainer;
