import IconList from './IconList';

export default IconList;
