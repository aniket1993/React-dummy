import ReactLogo from './ReactLogo';

export default ReactLogo;
