### 默认

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/city-simplified.json
 */

const instance = <CheckTree data={data} />;
ReactDOM.render(instance);
```

<!--end-code-->
