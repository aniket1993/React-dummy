### 虚拟列表

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/city-simplified.json
 */

const instance = <CheckTree data={data} virtualized defaultExpandAll />;
ReactDOM.render(instance);
```

<!--end-code-->
