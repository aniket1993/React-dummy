### Default

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/en/city-simplified.json
 */

const instance = <CheckTree data={data} />;
ReactDOM.render(instance);
```

<!--end-code-->
