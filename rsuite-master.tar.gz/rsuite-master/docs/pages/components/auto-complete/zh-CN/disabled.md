### 禁用

<!--start-code-->

```js
const data = [
  'HYPER Advertiser',
  'HYPER Web Analytics',
  'HYPER Video Analytics',
  'HYPER DMP',
  'HYPER Ad Serving',
  'HYPER Data Discovery'
];
const instance = <AutoComplete data={data} disabled />;

ReactDOM.render(instance);
```

<!--end-code-->
