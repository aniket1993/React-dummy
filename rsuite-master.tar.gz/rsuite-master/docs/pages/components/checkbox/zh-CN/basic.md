### 默认

<!--start-code-->
```js
const instance = (
  <div>
    <Checkbox> Default</Checkbox>
    <Checkbox defaultChecked > Checked</Checkbox>
  </div>
);
ReactDOM.render(instance);
```
<!--end-code-->
