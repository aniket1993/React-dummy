### 禁用

<!--start-code-->
```js
const instance = (
  <div>
    <Checkbox disabled> Default</Checkbox>
    <Checkbox defaultChecked disabled> Checked</Checkbox>
  </div>
);
ReactDOM.render(instance);
```
<!--end-code-->