# CSS Reset

With regard to typography, after using the React Suite style, you can use the HTML elements to typeset directly for displaying titles, paragraphs, lists, links, and more.

> If you don't need these styles , you can [disable import it][config-reset-import].

<!--{demo}-->

[config-reset-import]: /en/guide/themes#Disable%20styles%20reset
