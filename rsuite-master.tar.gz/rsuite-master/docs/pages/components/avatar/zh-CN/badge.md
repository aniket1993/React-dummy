### 徽标

<!--start-code-->

```js
const instance = (
  <div className="avatar-group">
    <Badge>
      <Avatar>
        <Icon icon={AvatarUser} />
      </Avatar>
    </Badge>

    <Badge content="20">
      <Avatar>
        <Icon icon={AvatarUser} />
      </Avatar>
    </Badge>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
