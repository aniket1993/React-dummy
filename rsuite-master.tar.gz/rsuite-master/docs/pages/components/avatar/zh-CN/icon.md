### 图标

<!--start-code-->

```js
const instance = (
  <div className="avatar-group">
    <Avatar>
      <Icon icon="user" />
    </Avatar>
    <Avatar>
      <Icon icon={AvatarUser} />
    </Avatar>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
