### Size

<!--start-code-->

```js
const instance = (
  <div className="avatar-group">
    <Avatar size="lg">RS</Avatar>
    <Avatar size="md">RS</Avatar>
    <Avatar size="sm">RS</Avatar>
    <Avatar size="xs">RS</Avatar>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
