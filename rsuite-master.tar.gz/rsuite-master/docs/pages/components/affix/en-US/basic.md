### Default

<!--start-code-->

```js
const instance = (
  <div>
    <Affix>
      <Button appearance="primary">Top 0</Button>
    </Affix>
    <Paragraph rows={6} />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
