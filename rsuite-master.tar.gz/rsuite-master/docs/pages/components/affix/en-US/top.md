### Top

<!--start-code-->

```js
const instance = (
  <div>
    <Affix top={50}>
      <Button appearance="primary">Top 50</Button>
    </Affix>
    <Paragraph rows={12} />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
