### Default

<!--start-code-->

```js
const instance = (
  <div className="show-grid">
    <FlexboxGrid>
      <FlexboxGrid.Item colspan={6}>colspan={6}</FlexboxGrid.Item>
      <FlexboxGrid.Item colspan={6}>colspan={6}</FlexboxGrid.Item>
      <FlexboxGrid.Item colspan={6}>colspan={6}</FlexboxGrid.Item>
      <FlexboxGrid.Item colspan={6}>colspan={6}</FlexboxGrid.Item>
    </FlexboxGrid>
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
