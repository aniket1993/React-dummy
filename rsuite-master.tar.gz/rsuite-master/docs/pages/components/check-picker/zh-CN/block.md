### 撑满

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/users-role.json
 */

const instance = <CheckPicker data={data} block />;
ReactDOM.render(instance);
```

<!--end-code-->
