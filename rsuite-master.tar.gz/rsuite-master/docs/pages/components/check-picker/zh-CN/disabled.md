### 禁用

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/users-role.json
 */

const instance = (
  <div>
    <CheckPicker
      data={data}
      style={{ width: 224 }}
      defaultValue={['Julius']}
      disabled
    />
    <hr />
    <p>禁用选项</p>
    <CheckPicker
      data={data}
      style={{ width: 224 }}
      defaultValue={['Julius']}
      disabledItemValues={['Eugenia', 'Travon', 'Vincenza']}
    />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
