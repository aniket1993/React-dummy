### Placeholder

<!--start-code-->
```js
const instance=(
  <DatePicker placeholder="选择日期" />
)
ReactDOM.render(instance);
```
<!--end-code-->
