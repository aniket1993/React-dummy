### 一键选值

<!--start-code-->

```js
const instance = <DatePicker oneTap style={{ width: 280 }} />;
ReactDOM.render(instance);
```

<!--end-code-->
