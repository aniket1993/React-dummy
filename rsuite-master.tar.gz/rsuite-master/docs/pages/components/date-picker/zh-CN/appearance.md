### 外观

<!--start-code-->

```js
const instance = (
  <div>
    <DatePicker appearance="default" placeholder="Default" style={{ width: 280 }} />
    <hr />
    <DatePicker appearance="subtle" placeholder="Subtle" style={{ width: 280 }} />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
