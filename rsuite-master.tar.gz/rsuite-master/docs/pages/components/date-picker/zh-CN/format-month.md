### 只显示月份

<!--start-code-->
```js
const DatePickerInstance = props => (
   <DatePicker format="YYYY-MM" ranges={[]} />
);

ReactDOM.render(<DatePickerInstance />);

```
<!--end-code-->