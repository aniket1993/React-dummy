### Block

<!--start-code-->

```js
const instance = <DatePicker block />;
ReactDOM.render(instance);
```

<!--end-code-->
