### Default

<!--start-code-->

```js
const instance = <DatePicker style={{ width: 280 }} />;
ReactDOM.render(instance);
```

<!--end-code-->
