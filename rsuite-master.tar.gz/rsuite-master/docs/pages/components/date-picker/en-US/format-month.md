### Show Month

<!--start-code-->
```js
const DatePickerInstance = props => (
   <DatePicker format="YYYY-MM" ranges={[]} />
);

ReactDOM.render(<DatePickerInstance />);

```
<!--end-code-->