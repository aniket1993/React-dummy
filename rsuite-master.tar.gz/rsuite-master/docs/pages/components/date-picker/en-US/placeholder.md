### Placeholder

<!--start-code-->
```js
const instance=(
  <DatePicker placeholder="Select Date" />
)
ReactDOM.render(instance);
```
<!--end-code-->
