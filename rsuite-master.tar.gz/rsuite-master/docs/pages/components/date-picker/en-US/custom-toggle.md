### Use with the button

<!--start-code-->

```js
const instance = (
  <div>
    <DatePicker toggleComponentClass={Button} />
    <hr />
    <DatePicker block toggleComponentClass={Button} />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
