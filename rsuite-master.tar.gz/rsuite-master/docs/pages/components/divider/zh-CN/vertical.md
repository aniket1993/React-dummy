### 垂直分割线

<!--start-code-->

```js
const instance = (
  <div>
    <a>Edit</a>
    <Divider vertical />
    <a>Update</a>
    <Divider vertical />
    <a>Save</a>
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
