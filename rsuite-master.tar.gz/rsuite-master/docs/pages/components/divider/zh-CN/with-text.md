### 带文本的

<!--start-code-->

```js
const instance = (
  <div>
    <Paragraph  />
    <Divider>Divider</Divider>
    <Paragraph />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
