### 默认

<!--start-code-->

```js
const instance = (
  <div>
    <Paragraph />
    <Divider />
    <Paragraph />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
