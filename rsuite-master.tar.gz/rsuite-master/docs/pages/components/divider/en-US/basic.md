### Default

<!--start-code-->

```js
const instance = (
  <div>
    <Paragraph type="media" />
    <Divider />
    <Paragraph type="media" />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
