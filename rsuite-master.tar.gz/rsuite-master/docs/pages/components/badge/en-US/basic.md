### Default

<!--start-code-->

```js
const instance = (
  <div>
    <Badge>
      <Button>New Message</Button>
    </Badge>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
