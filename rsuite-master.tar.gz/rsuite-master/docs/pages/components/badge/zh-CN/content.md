### 附加内容

<!--start-code-->

```js
const instance = (
  <div>
    <Badge content={999}>
      <Button>新消息</Button>
    </Badge>

    <Badge content="NEW">
      <Button>新消息</Button>
    </Badge>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
