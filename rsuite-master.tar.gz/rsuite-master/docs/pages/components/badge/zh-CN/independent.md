### 独立使用

<!--start-code-->

```js
const instance = (
  <div>
    <Badge />

    <Badge style={{ background: '#4caf50' }} />

    <Badge content="99+" />

    <Badge content="NEW" />
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
