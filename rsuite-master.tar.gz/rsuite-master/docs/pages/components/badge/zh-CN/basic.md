### 默认

<!--start-code-->

```js
const instance = (
  <div>
    <Badge>
      <Button>新消息</Button>
    </Badge>
  </div>
);

ReactDOM.render(instance);
```

<!--end-code-->
