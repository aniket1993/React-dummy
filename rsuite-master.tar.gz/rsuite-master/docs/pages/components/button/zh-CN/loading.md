### 加载中状态

<!--start-code-->
```js
const instance = (
  <ButtonToolbar>
    <Button appearance="default" loading>Default</Button>
    <Button appearance="primary" loading>Primary</Button>
    <Button appearance="link" loading>Link</Button>
    <Button appearance="subtle" loading>Subtle</Button>
    <Button appearance="ghost" loading>Ghost</Button>
  </ButtonToolbar>
);
ReactDOM.render(instance);
```
<!--end-code-->