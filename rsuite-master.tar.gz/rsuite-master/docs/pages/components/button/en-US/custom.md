### Custom combination button

<!--start-code-->
```js
const instance = (
  <ButtonToolbar>
    <Button color="blue" >
      <Icon icon="facebook-official"  /> Facebook
    </Button>
    <Button color="red" >
      <Icon icon="google-plus-circle"  /> Google Plus
    </Button>
    <Button color="cyan" >
      <Icon icon="twitter"  /> Twitter
    </Button>
    <Button color="blue" >
      <Icon icon="linkedin"  /> LinkedIn
    </Button>
    <Button color="green" >
      <Icon icon="wechat"  /> WeChat
    </Button>
    <Button color="yellow" >
      <Icon icon="weibo"  /> WeiBo
    </Button>

  </ButtonToolbar>
);
ReactDOM.render(instance);
```
<!--end-code-->