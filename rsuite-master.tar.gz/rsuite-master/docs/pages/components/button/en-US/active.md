### Active state

<!--start-code-->
```js
const instance = (
  <ButtonToolbar>
    <Button appearance="default" active>Default</Button>
    <Button appearance="primary" active>Primary</Button>
    <Button appearance="link" active>Link</Button>
    <Button appearance="subtle" active>Subtle</Button>
    <Button appearance="ghost" active>Ghost</Button>
  </ButtonToolbar>
);
ReactDOM.render(instance);
```
<!--end-code-->