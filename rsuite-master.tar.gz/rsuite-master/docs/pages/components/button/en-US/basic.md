### Default

<!--start-code-->
```js
const instance = (
  <Button>Default</Button>
);
ReactDOM.render(instance);
```
<!--end-code-->