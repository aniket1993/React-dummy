### Parent selectable

<!--start-code-->

```js
/**
 * import data from
 * https://github.com/rsuite/rsuite/blob/master/docs/public/data/province-simplified.json
 */

const instance = (
  <Cascader data={data} parentSelectable style={{ width: 224 }} />
);
ReactDOM.render(instance);
```

<!--end-code-->
