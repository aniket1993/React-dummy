### Use with the button

<!--start-code-->

```js
const instance = (
  <div>
    <DateRangePicker toggleComponentClass={Button} />
    <hr />
    <DateRangePicker block toggleComponentClass={Button} />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
