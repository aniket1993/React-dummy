### Appearance

<!--start-code-->

```js
const instance = (
  <div>
    <DateRangePicker
      appearance="default"
      placeholder="Defult"
      style={{ width: 280 }}
    />
    <hr />
    <DateRangePicker
      appearance="subtle"
      placeholder="Subtle"
      style={{ width: 280 }}
    />
  </div>
);
ReactDOM.render(instance);
```

<!--end-code-->
