### Placeholder

<!--start-code-->

```js
const instance = <DateRangePicker placeholder="Select Date Range" />;
ReactDOM.render(instance);
```

<!--end-code-->
