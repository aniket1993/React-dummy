### Show One Calendar

<!--start-code-->

```js
const instance = <DateRangePicker showOneCalendar />;
ReactDOM.render(instance);
```

<!--end-code-->
