### Block

<!--start-code-->

```js
const instance = <DateRangePicker block />;
ReactDOM.render(instance);
```

<!--end-code-->
