### 显示一个日历

<!--start-code-->

```js
const instance = <DateRangePicker showOneCalendar />;
ReactDOM.render(instance);
```

<!--end-code-->
