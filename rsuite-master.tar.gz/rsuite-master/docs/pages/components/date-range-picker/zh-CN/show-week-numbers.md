### 显示周数

<!--start-code-->

```js
const instance = <DateRangePicker showWeekNumbers />;
ReactDOM.render(instance);
```

<!--end-code-->
