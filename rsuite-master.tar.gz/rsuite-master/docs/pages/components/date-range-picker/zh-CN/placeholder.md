### Placeholder

<!--start-code-->

```js
const instance = <DateRangePicker placeholder="选择日期范围" />;
ReactDOM.render(instance);
```

<!--end-code-->
