### 默认

<!--start-code-->

```js
const instance = <DateRangePicker />;
ReactDOM.render(instance);
```

<!--end-code-->
