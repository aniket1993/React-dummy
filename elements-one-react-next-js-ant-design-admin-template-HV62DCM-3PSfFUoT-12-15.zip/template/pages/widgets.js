import Widgets from '../components/Widgets';

const WidgetsPage = () => <Widgets />;

export default WidgetsPage;
