import Demo from '../../demos/antd/list/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
