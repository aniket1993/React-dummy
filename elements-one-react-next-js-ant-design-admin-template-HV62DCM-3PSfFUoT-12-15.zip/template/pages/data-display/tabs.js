import Demo from '../../demos/antd/tabs/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
