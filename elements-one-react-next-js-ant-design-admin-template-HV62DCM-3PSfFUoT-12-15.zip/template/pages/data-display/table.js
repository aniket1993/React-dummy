import Demo from '../../demos/antd/table/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
