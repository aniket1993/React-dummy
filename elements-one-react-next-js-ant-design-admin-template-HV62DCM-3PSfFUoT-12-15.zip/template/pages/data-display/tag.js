import Demo from '../../demos/antd/tag/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
