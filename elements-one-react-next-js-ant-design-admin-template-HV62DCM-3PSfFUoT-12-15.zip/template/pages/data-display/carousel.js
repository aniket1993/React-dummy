import Demo from '../../demos/antd/carousel/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
