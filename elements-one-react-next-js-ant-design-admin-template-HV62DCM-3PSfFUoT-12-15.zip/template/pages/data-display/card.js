import Demo from '../../demos/antd/card/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
