import Demo from '../../demos/antd/collapse/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
