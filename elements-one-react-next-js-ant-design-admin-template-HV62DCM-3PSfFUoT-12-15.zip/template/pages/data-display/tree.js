import Demo from '../../demos/antd/tree/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
