import Demo from '../../demos/antd/badge/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
