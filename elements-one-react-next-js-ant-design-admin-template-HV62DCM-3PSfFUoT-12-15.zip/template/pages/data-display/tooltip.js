import Demo from '../../demos/antd/tooltip/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
