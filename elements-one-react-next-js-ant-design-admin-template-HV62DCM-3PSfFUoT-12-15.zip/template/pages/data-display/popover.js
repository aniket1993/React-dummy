import Demo from '../../demos/antd/popover/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
