import Demo from '../../demos/antd/calendar/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
