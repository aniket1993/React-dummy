import Demo from '../../demos/antd/avatar/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
