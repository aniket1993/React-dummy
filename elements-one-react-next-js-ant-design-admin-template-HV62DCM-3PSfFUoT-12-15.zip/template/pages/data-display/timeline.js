import Demo from '../../demos/antd/timeline/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
