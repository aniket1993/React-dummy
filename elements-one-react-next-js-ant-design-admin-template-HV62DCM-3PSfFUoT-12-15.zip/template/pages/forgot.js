import Forgot from '../components/Forgot';

const ForgotPage = () => <Forgot />;

export default ForgotPage;
