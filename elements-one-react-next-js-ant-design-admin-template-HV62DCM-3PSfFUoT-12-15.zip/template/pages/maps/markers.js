import MapMarkers from '../../components/MapMarkers';

const MapMarkersPage = () => <MapMarkers />;

export default MapMarkersPage;
