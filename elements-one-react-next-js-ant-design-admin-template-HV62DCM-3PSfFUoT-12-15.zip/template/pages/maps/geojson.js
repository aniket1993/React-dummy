import GeoJson from '../../components/GeoJson';

const GeoJsonPage = () => <GeoJson />;

export default GeoJsonPage;
