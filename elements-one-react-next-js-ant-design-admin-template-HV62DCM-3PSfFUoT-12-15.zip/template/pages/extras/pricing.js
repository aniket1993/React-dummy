import Pricing from '../../components/Pricing';

const PricingPage = () => <Pricing />;

export default PricingPage;
