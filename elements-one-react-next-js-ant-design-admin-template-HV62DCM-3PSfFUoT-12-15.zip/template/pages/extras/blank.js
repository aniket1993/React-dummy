const Blank = () => <p>Blank</p>;

export default Blank;
