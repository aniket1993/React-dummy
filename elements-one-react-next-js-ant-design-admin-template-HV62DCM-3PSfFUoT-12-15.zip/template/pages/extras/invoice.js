import Invoice from '../../components/Invoice';

const InvoicePage = () => <Invoice />;

export default InvoicePage;
