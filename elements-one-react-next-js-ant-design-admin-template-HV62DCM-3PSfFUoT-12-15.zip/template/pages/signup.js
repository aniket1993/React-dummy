import Signup from '../components/Signup';

const SignupPage = () => <Signup />;

export default SignupPage;
