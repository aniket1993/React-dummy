import LockScreen from '../components/LockScreen';

const LockScreenPage = () => <LockScreen />;

export default LockScreenPage;
