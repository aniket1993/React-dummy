import Modal from '../../demos/antd/modal/demo';

const ModalPage = () => <Modal />;

export default ModalPage;
