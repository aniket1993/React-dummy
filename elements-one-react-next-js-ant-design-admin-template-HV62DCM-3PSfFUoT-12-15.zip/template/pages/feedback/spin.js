import Spin from '../../demos/antd/spin/demo';

const SpinPage = () => <Spin />;

export default SpinPage;
