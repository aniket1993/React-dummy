import Feedback from '../../demos/antd/alert/demo';

const FeedbackPage = () => <Feedback />;

export default FeedbackPage;
