import Skeleton from '../../demos/antd/skeleton/demo';

const SkeletonPage = () => <Skeleton />;

export default SkeletonPage;
