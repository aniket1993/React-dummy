import Drawer from '../../demos/antd/drawer/demo';

const DrawerPage = () => <Drawer />;

export default DrawerPage;
