import Notification from '../../demos/antd/notification/demo';

const NotificationPage = () => <Notification />;

export default NotificationPage;
