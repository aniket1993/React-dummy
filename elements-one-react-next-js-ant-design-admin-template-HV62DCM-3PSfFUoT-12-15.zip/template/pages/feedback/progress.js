import Progress from '../../demos/antd/progress/demo';

const ProgressPage = () => <Progress />;

export default ProgressPage;
