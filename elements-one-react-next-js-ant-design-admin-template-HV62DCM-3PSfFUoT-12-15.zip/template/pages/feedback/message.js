import Message from '../../demos/antd/message/demo';

const MessagePage = () => <Message />;

export default MessagePage;
