import PopConfirm from '../../demos/antd/popconfirm/demo';

const PopConfirmPage = () => <PopConfirm />;

export default PopConfirmPage;
