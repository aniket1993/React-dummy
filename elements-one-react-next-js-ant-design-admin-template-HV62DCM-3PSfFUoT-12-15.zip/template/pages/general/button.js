import Button from '../../demos/antd/button/demo';

const ButtonPage = () => <Button />;

export default ButtonPage;
