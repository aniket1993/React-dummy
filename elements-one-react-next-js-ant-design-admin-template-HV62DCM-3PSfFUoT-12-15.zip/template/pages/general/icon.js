import Icon from '../../demos/antd/icon/demo';

const IconPage = () => <Icon />;

export default IconPage;
