import Affix from '../../demos/antd/affix/demo';

const AffixPage = () => <Affix />;

export default AffixPage;
