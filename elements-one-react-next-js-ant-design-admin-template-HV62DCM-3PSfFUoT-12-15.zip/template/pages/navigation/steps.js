import Steps from '../../demos/antd/steps/demo';

const StepsPage = () => <Steps />;

export default StepsPage;
