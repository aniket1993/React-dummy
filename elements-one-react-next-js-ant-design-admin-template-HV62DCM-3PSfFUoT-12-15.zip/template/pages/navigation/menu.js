import Menu from '../../demos/antd/menu/demo';

const MenuPage = () => <Menu />;

export default MenuPage;
