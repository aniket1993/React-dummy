import Pagination from '../../demos/antd/pagination/demo';

const PaginationPage = () => <Pagination />;

export default PaginationPage;
