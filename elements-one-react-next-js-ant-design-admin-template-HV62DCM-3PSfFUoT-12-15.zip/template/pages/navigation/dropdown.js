import Dropdown from '../../demos/antd/dropdown/demo';

const DropdownPage = () => <Dropdown />;

export default DropdownPage;
