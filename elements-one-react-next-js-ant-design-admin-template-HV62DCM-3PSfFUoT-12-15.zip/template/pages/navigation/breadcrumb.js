import Breadcrumbs from '../../demos/antd/breadcrumb/demo';

const BreadcrumbsPage = () => <Breadcrumbs />;

export default BreadcrumbsPage;
