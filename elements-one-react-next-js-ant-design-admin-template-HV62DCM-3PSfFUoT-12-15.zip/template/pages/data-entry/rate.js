import Demo from '../../demos/antd/rate/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
