import Demo from '../../demos/antd/switch/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
