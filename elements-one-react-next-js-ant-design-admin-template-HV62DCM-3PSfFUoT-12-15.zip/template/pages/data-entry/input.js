import Demo from '../../demos/antd/input/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
