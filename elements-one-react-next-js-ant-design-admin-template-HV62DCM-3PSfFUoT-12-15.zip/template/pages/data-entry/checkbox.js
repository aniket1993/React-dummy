import Demo from '../../demos/antd/checkbox/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
