import Demo from '../../demos/antd/mention/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
