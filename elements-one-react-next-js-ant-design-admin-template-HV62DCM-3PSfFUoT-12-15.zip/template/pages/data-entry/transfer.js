import Demo from '../../demos/antd/transfer/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
