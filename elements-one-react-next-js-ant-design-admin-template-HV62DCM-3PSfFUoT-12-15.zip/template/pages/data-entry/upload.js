import Demo from '../../demos/antd/upload/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
