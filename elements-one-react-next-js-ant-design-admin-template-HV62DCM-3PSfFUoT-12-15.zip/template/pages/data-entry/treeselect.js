import Demo from '../../demos/antd/tree-select/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
