import Demo from '../../demos/antd/select/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
