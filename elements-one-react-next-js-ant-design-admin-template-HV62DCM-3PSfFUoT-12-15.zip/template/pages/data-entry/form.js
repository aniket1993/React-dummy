import Demo from '../../demos/antd/form/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
