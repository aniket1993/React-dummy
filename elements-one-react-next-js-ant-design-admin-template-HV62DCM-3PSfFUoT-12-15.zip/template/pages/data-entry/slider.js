import Demo from '../../demos/antd/slider/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
