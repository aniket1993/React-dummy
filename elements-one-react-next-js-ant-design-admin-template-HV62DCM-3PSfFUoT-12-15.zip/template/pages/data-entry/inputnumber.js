import Demo from '../../demos/antd/input-number/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
