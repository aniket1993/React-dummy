import Demo from '../../demos/antd/autocomplete/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
