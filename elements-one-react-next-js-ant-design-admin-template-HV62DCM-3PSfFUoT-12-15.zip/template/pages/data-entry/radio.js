import Demo from '../../demos/antd/radio/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
