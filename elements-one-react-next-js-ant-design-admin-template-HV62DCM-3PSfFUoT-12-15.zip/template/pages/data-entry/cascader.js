import Demo from '../../demos/antd/cascader/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
