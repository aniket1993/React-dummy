import Demo from '../../demos/antd/time-picker/demo';

const DemoPage = () => <Demo />;

export default DemoPage;
