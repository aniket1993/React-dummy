import Grid from '../../components/Grid';

const GridPage = () => <Grid />;

export default GridPage;
