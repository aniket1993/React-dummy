import Tile from '../../components/Tile';

const TilePage = () => <Tile />;

export default TilePage;
