import Social from '../../components/Social';

const SocialPage = () => <Social />;

export default SocialPage;
