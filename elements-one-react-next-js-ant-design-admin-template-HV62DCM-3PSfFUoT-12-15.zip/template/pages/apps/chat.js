import Chat from '../../components/Chat';

const ChatPage = () => <Chat />;

export default ChatPage;
