import Messages from '../../components/Messages';

const MessagesPage = () => <Messages />;

export default MessagesPage;
