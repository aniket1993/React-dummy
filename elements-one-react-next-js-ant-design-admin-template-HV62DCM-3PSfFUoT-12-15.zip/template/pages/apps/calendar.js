import Calendar from '../../components/Calendar';

const CalendarPage = () => <Calendar />;

export default CalendarPage;
