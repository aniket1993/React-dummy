import Taskboard from '../components/Taskboard';

const TaskboardPage = () => <Taskboard />;

export default TaskboardPage;
