import { TimePicker } from 'antd';

const Component = () => <TimePicker minuteStep={15} secondStep={10} />;
export default Component;
