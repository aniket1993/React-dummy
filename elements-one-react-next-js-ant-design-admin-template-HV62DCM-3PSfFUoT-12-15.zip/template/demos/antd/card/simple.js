import { Card } from 'antd';

const Component = () => (
  <Card>
    <p>Card content</p>
    <p>Card content</p>
    <p>Card content</p>
  </Card>
);

export default Component;
