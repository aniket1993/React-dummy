import { Alert } from 'antd';

const Component = () => <Alert message="Success Text" type="success" />;

export default Component;
