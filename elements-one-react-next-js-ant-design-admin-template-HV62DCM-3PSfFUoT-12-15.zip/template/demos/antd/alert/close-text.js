import { Alert } from 'antd';

const Component = () => (
  <Alert message="Info Text" type="info" closeText="Close Now" />
);

export default Component;
