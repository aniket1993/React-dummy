import { Rate } from 'antd';

const Component = () => <Rate disabled defaultValue={2} />;
export default Component;
