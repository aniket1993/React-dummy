import { Rate } from 'antd';

const Component = () => <Rate allowHalf defaultValue={2.5} />;
export default Component;
