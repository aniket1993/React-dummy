import { Rate } from 'antd';

const Component = () => <Rate />;

export default Component;
