import { Skeleton } from 'antd';

const Component = () => <Skeleton active />;
export default Component;
