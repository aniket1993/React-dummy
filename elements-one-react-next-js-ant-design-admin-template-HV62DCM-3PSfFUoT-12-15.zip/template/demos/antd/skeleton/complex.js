import { Skeleton } from 'antd';

const Component = () => <Skeleton avatar paragraph={{ rows: 4 }} />;
export default Component;
