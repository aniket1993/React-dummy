import { Skeleton } from 'antd';

const Component = () => <Skeleton />;
export default Component;
