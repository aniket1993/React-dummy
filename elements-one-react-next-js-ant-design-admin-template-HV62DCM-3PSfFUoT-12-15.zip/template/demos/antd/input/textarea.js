import { Input } from 'antd';

const { TextArea } = Input;

const Component = () => <TextArea rows={4} />;

export default Component;
