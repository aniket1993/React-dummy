import { Input } from 'antd';

const Component = () => <Input placeholder="Basic usage" />;

export default Component;
