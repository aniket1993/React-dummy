import { Tooltip } from 'antd';

const Component = () => (
  <Tooltip title="prompt text">
    <span>Tooltip will show when mouse enter.</span>
  </Tooltip>
);
export default Component;
