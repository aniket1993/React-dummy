import { Radio } from 'antd';

const Component = () => <Radio>Radio</Radio>;
export default Component;
