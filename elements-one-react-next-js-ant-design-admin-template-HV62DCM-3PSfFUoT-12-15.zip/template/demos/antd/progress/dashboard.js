import { Progress } from 'antd';

const Component = () => <Progress type="dashboard" percent={75} />;

export default Component;
