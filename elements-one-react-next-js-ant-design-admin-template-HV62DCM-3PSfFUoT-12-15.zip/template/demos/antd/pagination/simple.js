import { Pagination } from 'antd';

const Component = () => <Pagination simple defaultCurrent={2} total={50} />;
export default Component;
