import { Pagination } from 'antd';

const Component = () => <Pagination defaultCurrent={6} total={500} />;
export default Component;
