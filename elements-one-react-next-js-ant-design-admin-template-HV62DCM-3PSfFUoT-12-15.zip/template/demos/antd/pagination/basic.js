import { Pagination } from 'antd';

const Component = () => <Pagination defaultCurrent={1} total={50} />;

export default Component;
