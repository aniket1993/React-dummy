import { Checkbox } from 'antd';

const Component = () => (
  <div>
    <Checkbox defaultChecked={false} disabled />
    <br />
    <Checkbox defaultChecked disabled />
  </div>
);

export default Component;
